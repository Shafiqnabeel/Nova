# NOVA — Final Error Email Demo

This version keeps the live operational error-email demo and removes the real ASN confirmation email.

## What is real
- Open an exception shipment
- Nova prepares the concise Reply All draft
- Click Approve & Send
- The error email is sent to the configured Demo Recipient

## What is simulated
- ASN generation
- ASN confirmation
- Final confirmation is logged inside Nova only
- No real confirmation email is sent after ASN confirmation

This preserves the stable error-email flow used in the earlier demo version.
