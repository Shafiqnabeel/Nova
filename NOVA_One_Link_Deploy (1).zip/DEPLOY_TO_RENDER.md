# NOVA — One-Link Deployment

After one-time deployment, presentation day is simply: open the NOVA website.

No black terminal window, no BAT file, no VBS file, no localhost server.

## One-time setup
1. Create a GitHub repository.
2. Upload all files from this folder.
3. In Render, create a Blueprint/Web Service from that repository.
4. Let Render detect `render.yaml`.
5. Add `RESEND_API_KEY` as a secret environment variable.
6. Deploy.
7. Use the Render URL as your NOVA website.

Real exception emails remain enabled.
ASN confirmation stays simulated/logged only and does not send a real email.
